#include <iostream>
#include <math.h>

using namespace std;

double fun(double x) {
    return 2 * log(x + 2) - 3;
}


double bisection(double a, double b, double eps) {
    double x = (a + b) / 2;
    double fx = fun(x);
    
    cout << "Metoda bisekcji dla x = " << x << " fx = " << fx << endl;
    
    if (abs(fx) <= eps) {
        return x;
    }
    
    if (fun(a) * fx < 0) {
        return bisection(a, x, eps);
    } else {
        return bisection(x, b, eps);
    }
}


int main() {
    double x0 = bisection(1, 8, 0.0001);
    cout << "Znaleziono miejsce zerowe w x = " << x0 << endl;
    return 0;
}
