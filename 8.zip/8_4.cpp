#include <iostream>
#include <math.h>

using namespace std;

double X[] = { -1 * M_PI / 6, 0, M_PI / 6, M_PI / 4, M_PI / 3, M_PI / 2 };
double Y[] = { 0.77, 0.95, 0.65, 0.5, 0.35, 0.1 };
int n = 5;

double fun(double x) {
    return 1.16974 * cos(x) - 0.277554;
}

double lagrange(double xp) {
    double yp = 0;
    
    for (int i = 1; i <= n; i++) {
        double p = 1;
        
        for (int j = 1; j <= n; j++) {
            if (i != j) {
                p = p * (xp - X[j]) / (X[i] - X[j]);
            }
        }
        
        yp = yp + p * Y[i];
    }
    
    return yp;
}


int main() {
    for (double x = -1 * M_PI / 6; x <= M_PI / 2; x += M_PI / 20) {
        cout << "x: " << x 
          << ", wartosc obliczona: " << lagrange(x) 
          << ", wartosc dokladna: " << fun(x) << endl;
    }
    
    return 0;
}
