#include <iostream>
#include <math.h>

using namespace std;

double fun(double x) {
    return 2 * (1 / (1 + x * x) + 1 / x);
}

double simpson(double start, double end, int n) {
    double integral = 0, st = 0;
    double dx = (end - start) / n;
    
    for (int i = 1; i <= n; i++) {
        double x = start + i * dx;
        st += fun(x - dx / 2);
        
        if (i < n) {
            integral += fun(x);
        }
    }
    
    integral = dx / 6 * (fun(start) + fun(end) + 2 * integral + 4 * st);
    
    return integral;
}

double rectangles(double start, double end, int n) {
    double integral = 0;
    double dx = (end - start) / n;
    
    for (int i = 0; i < n; i++) {
        double x = start + ((i + 1) * dx);
        double y = fun(x);
        
        integral += y * dx;
    }
    
    return integral;
}

int main() {
    double expected = 4.39488;
    
    double start = 1;
    double end = 5;
    double eps = 0.0001;
    
    int n = 1;
    int nStep = 1;
    double error = eps;
    double integral = 0;
    
    while (error >= eps) {
        n += nStep;
        integral = simpson(start, end, n);
        error = abs(integral - expected);
    }
    
    cout << "Wartosc calki oznaczonej dla metody simpsona: " << integral << endl;
    cout << "Wymagana liczba przedzialow: " << n + 1 << endl;
    cout << "Blad absolutny dla metody simpsona: " << abs(integral - expected) << endl;
    
    n = 1;
    nStep = 1;
    error = eps;
    
    while (error >= eps) {
        n += nStep;
        integral = rectangles(start, end, n);
        error = abs(integral - expected);
    }
    
    cout << "Wartosc calki oznaczonej dla metody prostokatow: " << integral << endl;
    cout << "Wymagana liczba prostokatow: " << n + 1 << endl;
    cout << "Blad absolutny dla metody prostokatow: " << abs(integral - expected) << endl;

    return 0;
}
