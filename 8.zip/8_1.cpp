#include <iostream>
#include <math.h>

using namespace std;

double X[] = { -1 * M_PI / 6, 0, M_PI / 6, M_PI / 4, M_PI / 3, M_PI / 2 };
double Y[] = { 0.77, 0.95, 0.65, 0.5, 0.35, 0.1 };
int n = 5;

int main() {
    double sx = 0, sy = 0, sx2 = 0, sxy = 0;
    
    for (int i = 0; i < n; i++) {
        X[i] = cos(X[i]);
    }
    
    for (int i = 0; i < n; i++) {
        sx += X[i];
        sy += Y[i];
        sx2 += X[i] * X[i];
        sxy += X[i] * Y[i];
    }
    
    double a = (n * sxy - sx * sy) / (n * sx2 - sx * sx);
    double b = (sy * sx2 - sx * sxy) / (n * sx2 - sx * sx);
    
    cout << "funkcja: " << a << " * cos(x) + " << b << endl;
    
    for (double x = -1 * M_PI / 6; x <= M_PI / 2; x += M_PI / 20) {
        double y = a * cos(x) + b;
        cout << "x: " << x << ", wartosc obliczona: " << y << endl;
        // cout << x << "," << y << endl;
    }
    
    return 0;
}
