#include <iostream>
#include <math.h>

using namespace std;

double fun(double x) {
    return 2 * sin(x) - x;
}

double der(double x) {
    return 2 * cos(x) - 1;
}

double newton(double x, double eps) {
    double fx = fun(x);
    
    cout << "Metoda newtona dla x = " << x << " fx = " << fx << endl;
    
    if (abs(fx) <= eps) {
        return x;
    }
    
    double dx = der(x);
    
    return newton(x - fx / dx, eps);
}

int main() {
    double a = M_PI / 2;
    double b = M_PI;
    double x0 = newton((a + b) / 2, 0.0001);
    cout << "Znaleziono miejsce zerowe w x = " << x0 << endl;
    return 0;
}
