#include <iostream>
#include <math.h>

using namespace std;

double X[] = { 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 1 };
double Y[] = { -1.2, -0.91, -0.69, -0.51, -0.36, -0.22, 0 };
int n = 6;

double fun(double x) {
    return log(x);
}

double lagrange(double xp) {
    double yp = 0;
    
    for (int i = 1; i <= n; i++) {
        double p = 1;
        
        for (int j = 1; j <= n; j++) {
            if (i != j) {
                p = p * (xp - X[j]) / (X[i] - X[j]);
            }
        }
        
        yp = yp + p * Y[i];
    }
    
    return yp;
}


int main() {
    for (double x = 0.5; x <= 0.85; x += 0.1) {
        cout << "x: " << x 
          << ", wartosc obliczona: " << lagrange(x) 
          << ", wartosc dokladna: " << fun(x) << endl;
    }
    
    return 0;
}
