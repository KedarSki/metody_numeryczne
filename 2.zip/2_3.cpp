#include <iostream>
#include <math.h>

using namespace std;

double X[] = { 0, M_PI / 6, M_PI / 4, M_PI / 3, M_PI / 2 };
double Y[] = { 0, 1 / 2, sqrt(2) / 2, sqrt(3) / 2, 1 };
int n = 5;

int main() {
    double A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0;
    
    for (int i = 0; i < n; i++) {
        A += pow(X[i], 4);
        B += pow(X[i], 3);
        C += pow(X[i], 2);
        D += X[i];
        E += Y[i] * pow(X[i], 2);
        F += Y[i] * X[i];
        G += Y[i];
    }
    
    double W = (A * C * n) + (B * D * C) + (C * B * D) - (C * C * C) - (D * D * A) - (n * B * B);
    double Wa = (E * C * n) + (F * D * C) + (G * B * D) - (G * C * C) - (D * D * E) - (n * F * B);
    double Wb = (A * F * n) + (B * G * C) + (C * E * D) - (C * F * C) - (G * D * A) - (n * B * E);
    double Wc = (A * C * G) + (B * D * E) + (C * B * F) - (C * C * E) - (D * F * A) - (G * B * B);
    double a = Wa / W;
    double b = Wb / W;
    double c = Wc / W;
    
    cout << "funkcja: " << a << " * x^2 + " << b << " * x + " << c << endl;
    
    for (double x = 0; x <= M_PI / 2; x += M_PI / 30) {
        double y = a * x * x + b * x + c;
        cout << "x: " << x << ", wartosc obliczona: " << y << ", wartosc dokladna: " << sin(x) << endl;
    }
    
    return 0;
}
