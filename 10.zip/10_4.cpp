#include <iostream>
#include <math.h>

using namespace std;

double X[] = { 0, 0.5, 1, 3, 4 };
double Y[] = { 1.2, 1.92, 3, 11.6, 24.4 };
int n = 4;

double fun(double x) {
    return 1.30526 * pow(2.08532, x);
}

double lagrange(double xp) {
    double yp = 0;
    
    for (int i = 1; i <= n; i++) {
        double p = 1;
        
        for (int j = 1; j <= n; j++) {
            if (i != j) {
                p = p * (xp - X[j]) / (X[i] - X[j]);
            }
        }
        
        yp = yp + p * Y[i];
    }
    
    return yp;
}


int main() {
    for (double x = 0; x <= 4.1; x += 0.2) {
        cout << "x: " << x 
          << ", wartosc obliczona: " << lagrange(x) 
          << ", wartosc dokladna: " << fun(x) << endl;
    }
    
    return 0;
}
