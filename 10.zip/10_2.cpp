#include <iostream>
#include <math.h>

using namespace std;

double fun(double x) {
    return 1 / (2 * x + 3) + 3 * x * x;
}

double trapezoids(double start, double end, int n) {
    double integral = 0;
    double dx = (end - start) / n;
    
    for (int i = 0; i < n; i++) {
        double x1 = start + (i * dx);
        double x2 = start + ((i + 1) * dx);
        double y1 = fun(x1);
        double y2 = fun(x2);
        
        integral += 0.5 * (y1 + y2) * dx;
    }
    
    return integral;
}

double rectangles(double start, double end, int n) {
    double integral = 0;
    double dx = (end - start) / n;
    
    for (int i = 0; i < n; i++) {
        double x = start + ((i + 1) * dx);
        double y = fun(x);
        
        integral += y * dx;
    }
    
    return integral;
}

int main() {
    double expected = 124.47775572251371;
    
    double start = 1;
    double end = 5;
    double eps = 0.00001;
    
    int n = 1;
    int nStep = 1;
    double error = eps;
    double integral = 0;
    
    while (error >= eps) {
        n += nStep;
        integral = rectangles(start, end, n);
        error = abs(integral - expected);
    }
    
    cout << "Wartosc calki oznaczonej dla metody prostokatow: " << integral << endl;
    cout << "Wymagana liczba prostokatow: " << n + 1 << endl;
    cout << "Blad absolutny dla metody prostokatow: " << abs(integral - expected) << endl;
    
    n = 1;
    nStep = 1;
    error = eps;
    
    while (error >= eps) {
        n += nStep;
        integral = trapezoids(start, end, n);
        error = abs(integral - expected);
    }
    
    cout << "Wartosc calki oznaczonej dla metody trapezow: " << integral << endl;
    cout << "Wymagana liczba trapezow: " << n + 1 << endl;
    cout << "Blad absolutny dla metody trapezow: " << abs(integral - expected) << endl;
    
    return 0;
}
