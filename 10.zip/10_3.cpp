#include <iostream>
#include <math.h>

using namespace std;

double X[] = { 0, 0.5, 1, 3, 4 };
double Y[] = { 1.2, 1.92, 3, 11.6, 24.4 };
int n = 5;

int main() {
    double sx = 0, sy = 0, sx2 = 0, sxy = 0;
    
    for (int i = 0; i < n; i++) {
        Y[i] = log(Y[i]);
    }
    
    for (int i = 0; i < n; i++) {
        sx += X[i];
        sy += Y[i];
        sx2 += X[i] * X[i];
        sxy += X[i] * Y[i];
    }
    
    double a2 = (n * sxy - sx * sy) / (n * sx2 - sx * sx);
    double a1 = (sy * sx2 - sx * sxy) / (n * sx2 - sx * sx);
    
    double a = exp(a1);
    double b = exp(a2);
    
    cout << "funkcja: " << a << " * " << b << "^x" << endl;
    
    for (double x = 0; x <= 4.1; x += 0.2) {
        double y = a * pow(b, x);
        cout << "x: " << x << ", wartosc obliczona: " << y << endl;
    }
    
    return 0;
}
